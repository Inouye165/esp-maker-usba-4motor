import json
import math
import os
import glob
import hashlib
from typing import Dict, Any, List

FILES = [
    ("Trial 1 (04:44:21)", "reports/floor_char_Reverse_Crawl_0.015mps_20261013_044421.json", 25.0),
    ("Trial 2 (04:52:49)", "reports/floor_char_Reverse_Crawl_0.015mps_20261013_045249.json", 30.0),
    ("Trial 3 (04:53:41)", "reports/floor_char_Reverse_Crawl_0.015mps_20261013_045341.json", 30.0),
    ("Trial 4 (04:54:17)", "reports/floor_char_Reverse_Crawl_0.015mps_20261013_045417.json", 30.0),
]

WHEELS = ["m1", "m2", "m3", "m4"]

def load_data():
    runs = []
    for label, path, phys_mm in FILES:
        with open(path, "rb") as f:
            raw = f.read()
            h = hashlib.sha256(raw).hexdigest()
        data = json.loads(raw.decode("utf-8"))
        runs.append({
            "label": label,
            "path": path,
            "sha256": h,
            "phys_mm": phys_mm,
            "data": data
        })
    return runs

def analyze():
    runs = load_data()
    print("=" * 100)
    print("OBJECTIVE 1: BASIC RUN METRICS AND INTEGRITY")
    print("=" * 100)
    
    for r in runs:
        d = r["data"]
        samples = d.get("samples", [])
        geom = d.get("geometry", {})
        mt = d.get("motion_tracking", {})
        cb = d.get("command_boundaries", {})
        comm = d.get("communication_status", {})
        stop = d.get("stopping", {})
        
        # Calculate sample timing gaps
        dt_gaps = []
        for i in range(1, len(samples)):
            dt = samples[i]["receipt_mono"] - samples[i-1]["receipt_mono"]
            dt_gaps.append(dt)
        max_gap = max(dt_gaps) if dt_gaps else 0.0
        avg_gap = sum(dt_gaps)/len(dt_gaps) if dt_gaps else 0.0
        
        cmd_duration = cb.get("command_duration_s", 0.0)
        script_profile = mt.get("script_command_profile_distance_m", 0.0) * 1000.0
        fw_target = mt.get("firmware_wheel_target_distance_m", 0.0) * 1000.0
        active_disp = mt.get("last_active_sample_distance_m", 0.0) * 1000.0
        stopped_disp = mt.get("final_stopped_encoder_distance_m", 0.0) * 1000.0
        rollout = stop.get("overrun_distance_mm", 0.0)
        settle_s = stop.get("settle_time_s", 0.0)
        
        print(f"\n{r['label']}:")
        print(f"  SHA-256:               {r['sha256']}")
        print(f"  Sample Count:          {len(samples)}")
        print(f"  Timing Gaps (s):       mean={avg_gap*1000:.1f}ms, max={max_gap*1000:.1f}ms (all < 250ms: {max_gap < 0.250})")
        print(f"  Command Duration:      {cmd_duration:.4f} s")
        print(f"  Script Command Dist:   {script_profile:.1f} mm")
        print(f"  Firmware Target Dist:  {fw_target:.1f} mm")
        print(f"  Active Displacement:   {active_disp:.1f} mm")
        print(f"  Final Stopped Displ:   {stopped_disp:.1f} mm")
        print(f"  Rollout:               {rollout:.1f} mm (Settle time: {settle_s:.3f} s)")
        print(f"  Physical Measurement:  {r['phys_mm']:.1f} mm")
        print(f"  Evaluator Outcome:     {d.get('status')}")

    print("\n" + "=" * 100)
    print("OBJECTIVE 2: PER-WHEEL DETAILED COMPARISON ACROSS ALL 4 RUNS")
    print("=" * 100)

    for r in runs:
        d = r["data"]
        samples = d.get("samples", [])
        m_per_tick = d.get("geometry", {}).get("meters_per_tick", 0.00010343783325453767)
        print(f"\n--- {r['label']} (Physical: {r['phys_mm']} mm, Encoder: {d.get('motion_tracking', {}).get('final_stopped_encoder_distance_m', 0)*1000:.1f} mm) ---")
        
        # Analyze active samples (seg_idx == 0 and cmd vx != 0)
        active_samples = [s for s in samples if s.get("cmd", {}).get("vx", 0.0) != 0.0]
        t_active_start = active_samples[0]["t_rel"] if active_samples else 0.0
        t_active_end = active_samples[-1]["t_rel"] if active_samples else 0.0
        
        print(f"Active window: t={t_active_start:.3f}s to {t_active_end:.3f}s (duration {t_active_end - t_active_start:.3f}s)")
        
        for w in WHEELS:
            # First tick / first movement time
            t_first_tick = None
            t_breakout = None
            boost_count = 0
            
            speeds_all = []
            speeds_post300 = []
            speeds_final500 = []
            
            pwms_all = []
            ff_all = []
            p_all = []
            i_all = []
            rec_all = []
            
            peak_rec = 0.0
            rec_active_count = 0
            stall_dwell_count = 0
            
            for s in active_samples:
                t = s["t_rel"]
                ticks = s.get("ticks", {}).get(w, 0)
                spd = s.get("measured_radps", {}).get(w, 0.0)
                
                # Check first movement (abs(ticks) >= 1)
                if abs(ticks) >= 1 and t_first_tick is None:
                    t_first_tick = t
                    
                # Check breakout (abs(ticks) >= 3)
                if abs(ticks) >= 3 and t_breakout is None:
                    t_breakout = t
                    
                stiction = s.get("stiction", {}).get(w, "")
                if stiction == "BOOST":
                    boost_count += 1
                    
                pid = s.get("pid_terms", {}).get(w, {})
                pwm = s.get("pwm", {}).get(w, 0)
                ff = pid.get("feedforward", 0.0)
                pt = pid.get("pTerm", 0.0)
                it = pid.get("iTerm", 0.0)
                rec = pid.get("recoveryAssist", 0.0)
                
                speeds_all.append(spd)
                if t >= t_active_start + 0.300:
                    speeds_post300.append(spd)
                if t >= t_active_end - 0.500:
                    speeds_final500.append(spd)
                    
                pwms_all.append(pwm)
                ff_all.append(ff)
                p_all.append(pt)
                i_all.append(it)
                rec_all.append(rec)
                
                if abs(rec) > peak_rec:
                    peak_rec = abs(rec)
                if abs(rec) > 0.1:
                    rec_active_count += 1
                if abs(spd) < 0.05 and t > t_active_start + 0.200:
                    stall_dwell_count += 1
            
            final_ticks = samples[-1].get("ticks", {}).get(w, 0)
            dist_065 = abs(final_ticks) * m_per_tick * 1000.0
            m_per_tick_06695 = (math.pi * 0.06695) / 1974.16666667
            dist_06695 = abs(final_ticks) * m_per_tick_06695 * 1000.0
            
            mean_spd = sum(speeds_all)/len(speeds_all) if speeds_all else 0.0
            mean_post300 = sum(speeds_post300)/len(speeds_post300) if speeds_post300 else 0.0
            mean_final500 = sum(speeds_final500)/len(speeds_final500) if speeds_final500 else 0.0
            
            mean_pwm = sum(pwms_all)/len(pwms_all) if pwms_all else 0.0
            mean_ff = sum(ff_all)/len(ff_all) if ff_all else 0.0
            mean_i = sum(i_all)/len(i_all) if i_all else 0.0
            
            print(f"  {w.upper()}:")
            print(f"    Ticks: {final_ticks:4d} | Dist (65mm): {dist_065:.2f} mm | Dist (66.95mm): {dist_06695:.2f} mm")
            print(f"    First tick: {t_first_tick:.3f}s | Breakout (>=3 ticks): {t_breakout:.3f}s | BOOST cycles: {boost_count}")
            print(f"    Speeds (rad/s): mean_all={mean_spd:.3f}, post300ms={mean_post300:.3f}, final500ms={mean_final500:.3f}")
            print(f"    PWM: mean={mean_pwm:.1f}, mean_FF={mean_ff:.1f}, mean_I={mean_i:.2f}")
            print(f"    Recovery Assist: peak={peak_rec:.1f} PWM, active_samples={rec_active_count}, stall_dwells={stall_dwell_count}")

if __name__ == "__main__":
    analyze()
